using System;
namespace Custom_EXE
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Diagnostics.Process.Start("calc.exe");
        }
    }
}
